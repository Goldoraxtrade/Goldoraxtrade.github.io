// server.js — Minimal backend for GoldoraX v8.0 (simple auth, file storage, WS)
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const http = require('http');
const WebSocket = require('ws');
const fetch = require('node-fetch');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const DATA_DIR = path.join(__dirname, 'data');
if(!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const REQS_FILE = path.join(DATA_DIR, 'reqs.json');

function readJSON(file, fallback){ try{ return JSON.parse(fs.readFileSync(file,'utf8')||'null') || fallback; }catch(e){ return fallback; }}
function writeJSON(file, obj){ fs.writeFileSync(file, JSON.stringify(obj, null, 2), 'utf8'); }

// init files
if(!fs.existsSync(USERS_FILE)) writeJSON(USERS_FILE, { demoUser:{ password: 'demo', balance:10000, positions:{}, portVal:0, created: new Date().toISOString() } });
if(!fs.existsSync(REQS_FILE)) writeJSON(REQS_FILE, []);

const PORT = process.env.PORT || 3000;
const ADMIN_PASS = process.env.ADMIN_PASS || 'adminyai774570';
const LINE_TARGET = process.env.LINE_TARGET || '';
const LINE_TOKEN = process.env.LINE_TOKEN || '';

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// CORS (restrict in prod)
app.use((req,res,next)=>{ res.setHeader('Access-Control-Allow-Origin','*'); res.setHeader('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS'); res.setHeader('Access-Control-Allow-Headers','Content-Type,Authorization'); next(); });

// Instruments (server-side)
const INSTRUMENTS = [
  { id:'GOLD/USD', thai:'ทองคำ', label:'Gold (XAU/USD)', price:2382.54, unit:'USD/oz' },
  { id:'BTC/USD', thai:'บิตคอยน์', label:'Bitcoin (BTC/USD)', price:64320.58, unit:'USD' },
  { id:'USD/THB', thai:'ดอลลาร์/บาท', label:'USD/THB Forex', price:36.85, unit:'บาท' }
];

const priceState = {};
const series = {};
INSTRUMENTS.forEach(it=>{ priceState[it.id] = it.price; series[it.id] = Array(120).fill(it.price); });

function tickOnce(){ INSTRUMENTS.forEach(inst=>{ const old = priceState[inst.id]; const bias = (Math.random()<0.5? -1: 1) * (Math.random()*0.004); const next = Math.max(0.0001, +(old*(1 + bias)).toFixed(2)); priceState[inst.id] = next; const s = series[inst.id]; s.push(next); if(s.length>120) s.shift(); }); }
setInterval(()=>{ tickOnce(); broadcast({ type:'prices', data:{ priceState, series } }); }, 3000);

function broadcast(msg){ const j = JSON.stringify(msg); wss.clients.forEach(c=>{ if(c.readyState===WebSocket.OPEN) c.send(j); }); }

// --- API ---
app.get('/api/instruments', (req,res)=>{ res.json({ instruments: INSTRUMENTS, prices: priceState }); });

// register with password
app.post('/api/register', (req,res)=>{
  const { username, password } = req.body; if(!username || !password) return res.status(400).json({error:'username/password required'});
  const users = readJSON(USERS_FILE, {});
  if(users[username]) return res.status(409).json({error:'user exists'});
  users[username] = { password, balance:1000, positions:{}, portVal:0, created:new Date().toISOString() };
  writeJSON(USERS_FILE, users);
  return res.json({ok:true, user:username});
});

// login verifies password
app.post('/api/login', (req,res)=>{
  const { username, password } = req.body; if(!username || !password) return res.status(400).json({error:'username/password required'});
  const users = readJSON(USERS_FILE, {});
  if(!users[username]) return res.status(404).json({error:'no user'});
  if(users[username].password !== password) return res.status(401).json({error:'invalid password'});
  const copy = {...users[username]}; delete copy.password; return res.json({ok:true, user:username, userData: copy});
});

app.get('/api/user/:u', (req,res)=>{ const users = readJSON(USERS_FILE, {}); const u = users[req.params.u]; if(!u) return res.status(404).json({error:'no user'}); const copy = {...u}; delete copy.password; res.json({user:req.params.u, data:copy}); });

app.post('/api/request', (req,res)=>{
  const { user, type, amount, note } = req.body; if(!user || !type || !amount) return res.status(400).json({error:'missing fields'});
  const list = readJSON(REQS_FILE, []);
  const id = 'req-'+Date.now().toString().slice(-6);
  const r = { id, user, type, amount, note:note||'', status:'pending', created:new Date().toISOString() };
  list.unshift(r); writeJSON(REQS_FILE, list);
  sendLineNotify({ user, type, amount, reqId: id }).catch(e=>console.warn('line push failed', e));
  return res.json({ok:true, req:r});
});

app.get('/api/requests', (req,res)=>{ const list = readJSON(REQS_FILE, []); res.json({requests:list}); });

app.post('/api/admin/approve', (req,res)=>{
  const { id, pass } = req.body; if(pass !== ADMIN_PASS) return res.status(403).json({error:'bad admin pass'});
  const list = readJSON(REQS_FILE, []); const idx = list.findIndex(x=>x.id===id); if(idx===-1) return res.status(404).json({error:'not found'});
  const r = list[idx]; if(r.status!=='pending') return res.status(400).json({error:'already processed'});
  r.status='approved'; r.processedAt = new Date().toISOString(); r.processedBy='admin'; list[idx]=r; writeJSON(REQS_FILE, list);
  const users = readJSON(USERS_FILE, {}); if(!users[r.user]) users[r.user] = { password:'', balance:0, positions:{}};
  if(r.type === 'deposit'){ users[r.user].balance = Number(( (users[r.user].balance||0) + r.amount ).toFixed(2)); }
  else { users[r.user].balance = Number(( (users[r.user].balance||0) - r.amount ).toFixed(2)); }
  writeJSON(USERS_FILE, users);
  sendLineNotify({ user:r.user, type:r.type, amount:r.amount, reqId:id, approved:true }).catch(()=>{});
  return res.json({ok:true, req:r});
});

async function sendLineNotify(payload){
  const msg = `📢 GoldoraX แจ้งเตือน\nผู้เล่น: ${payload.user}\nประเภท: ${payload.type}\nจำนวน: ${payload.amount} ฿\nรหัสคำขอ: ${payload.reqId}\n${payload.approved? 'สถานะ: อนุมัติ':''}`;
  if(!LINE_TOKEN || !LINE_TARGET){ console.log('LINE not configured — simulated message:', msg); return; }
  const body = { to: LINE_TARGET, messages:[{ type:'text', text: msg }] };
  const res = await fetch('https://api.line.me/v2/bot/message/push',{ method:'POST', headers:{ 'Content-Type':'application/json', 'Authorization':'Bearer '+LINE_TOKEN }, body: JSON.stringify(body) });
  if(!res.ok) console.warn('LINE push status', res.status);
}

app.post('/api/invite', (req,res)=>{ const { ref } = req.body; const token = Buffer.from(`${ref||'guest'}:${Date.now()}`).toString('base64'); const url = (process.env.BASE_URL || `http://localhost:${PORT}`) + '/?invite=' + encodeURIComponent(token); res.json({ok:true, url}); });

app.get('/ping', (req,res)=>res.json({ok:true, now: new Date().toISOString()}));

app.get('*', (req,res)=>{ res.sendFile(path.join(__dirname, 'public', 'goldora_login.html')); });

wss.on('connection', (ws)=>{ ws.send(JSON.stringify({ type:'hello', ts: Date.now(), prices: priceState })); ws.on('message',(m)=>{ try{ const msg = JSON.parse(m); if(msg && msg.type==='ping') ws.send(JSON.stringify({ type:'pong' })); }catch(e){} }); });

server.listen(PORT, ()=>{ console.log(`GoldoraX server listening on ${PORT}`); });
